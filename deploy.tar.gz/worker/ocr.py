import cv2
import re
import numpy as np
import structlog
from paddleocr import PaddleOCR
from config import worker_config

logger = structlog.get_logger()

# Standard Turkish plate regex patterns: 
# 1. 34 ABC 123 (City Code - Letters - Number)
# Matches: 2 digits + 1 to 3 letters + 2 to 4 digits
PLATE_REGEX = re.compile(r"^(0[1-9]|[1-7][0-9]|8[0-1])\s*[a-zA-Z]{1,3}\s*\d{2,4}$")

class PlateOCR:
    def __init__(self):
        try:
            # Initialize PaddleOCR with Turkish / English characters
            # lang='tr' supports Turkish letters (like Ç, Ğ, I, İ, Ö, Ş, Ü) which are common in older plates or custom plates
            self.ocr = PaddleOCR(lang='tr')
            logger.info("PaddleOCR engine loaded successfully")
        except Exception as e:
            logger.warning("PaddleOCR loading failed, using fallback regex simulation for dev testing", error=str(e))
            self.ocr = None

    def clean_text(self, text: str) -> str:
        # Clean spacing, symbols, and keep letters and digits
        cleaned = re.sub(r"[^A-Z0-9]", "", text.upper())
        return cleaned

    def validate_plate(self, text: str) -> bool:
        # Check standard Turkish plate rules
        # Add basic space formatting back for matching regex: e.g., "34ABC123" -> "34 ABC 123"
        # We search with a loose version of spacing
        cleaned = self.clean_text(text)
        match = PLATE_REGEX.match(cleaned)
        return match is not None

    def read_plate(self, crop: np.ndarray, is_full_frame: bool = False):
        """
        Reads plate text from cropped image. If is_full_frame is True,
        it scans all detected words for a valid Turkish plate.
        Returns: Tuple (plate_text, confidence)
        """
        if self.ocr is None or crop is None or crop.size == 0:
            return "", 0.0

        try:
            # For small crops (detected by YOLO), we apply image preprocessing to boost accuracy
            if not is_full_frame:
                h, w = crop.shape[:2]
                scale_factor = 3.0
                resized = cv2.resize(crop, (int(w * scale_factor), int(h * scale_factor)), interpolation=cv2.INTER_CUBIC)
                gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
                clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
                contrast = clahe.apply(gray)
                processed = cv2.adaptiveThreshold(
                    contrast, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
                )
                color_processed = cv2.cvtColor(processed, cv2.COLOR_GRAY2BGR)
                result = self.ocr.ocr(color_processed, cls=False)
                if not result or not result[0]:
                    result = self.ocr.ocr(crop, cls=False)
            else:
                # Full frame OCR - scan direct image to find text segments fast
                result = self.ocr.ocr(crop, cls=False)

            if not result or not result[0]:
                return "", 0.0
                
            # Scan all detected text regions to find the one matching plate format
            best_plate = ""
            best_conf = 0.0
            
            for line in result[0]:
                box, (raw_text, confidence) = line
                cleaned_text = self.clean_text(raw_text)
                
                # Check if this text segment looks like a Turkish plate
                if self.validate_plate(cleaned_text):
                    if confidence > best_conf:
                        best_plate = cleaned_text
                        best_conf = float(confidence)
            
            if best_plate:
                logger.info("Plate OCR detected from candidates", plate=best_plate, conf=best_conf)
                return best_plate, best_conf
                
            # Fallback to top match if it's not full-frame (YOLO cropped a plate block already)
            if not is_full_frame:
                best_match = result[0][0]
                box, (raw_text, confidence) = best_match
                cleaned_text = self.clean_text(raw_text)
                return cleaned_text, float(confidence)
                
            return "", 0.0
            
        except Exception as e:
            logger.error("OCR execution error", error=str(e))
            return "", 0.0
